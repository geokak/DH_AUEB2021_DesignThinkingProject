function toggleMenu() {
    let slider = document.querySelector('.slider');
    let advs = document.querySelector('.advantages');
    let main = document.querySelector('.main');
    let footer = document.querySelector('.footer');
    let menuToggle = document.querySelector('.menu-toggle');
    let menuToggleDisplayStatus = window.getComputedStyle(menuToggle).getPropertyValue('display');

    if (menuToggleDisplayStatus == "none") {
        menuToggle.style.display = "block";
        //slider.style.display = "none";
        //advs.style.display = "none";
        //main.style.display = "none";
        //footer.style.display = "none";
    } else {
        menuToggle.style.display = "none";
        slider.style.display = "block";
        advs.style.display = "flex";
        main.style.display = "block";
        footer.style.display = "flex";
    }
}

function myFunction() {
    let dots = document.querySelector(".dots");
    let moreText = document.querySelector(".more");
    let btnText = document.querySelector(".myBtn");
    let dotsStyleDisplay = window.getComputedStyle(moreText).getPropertyValue('display');
  
    if (dotsStyleDisplay == "none") {
      dots.style.display = "none";
      btnText.innerHTML = "Λιγότερα";
      moreText.style.display = "inline";
    } else {
      dots.style.display = "inline";
      btnText.innerHTML = "Περισσότερα";
      moreText.style.display = "none";
    }
  }

  function myFunction1() {
    let dots = document.querySelector(".dots1");
    let moreText = document.querySelector(".more1");
    let btnText = document.querySelector(".myBtn1");
    let dotsStyleDisplay = window.getComputedStyle(moreText).getPropertyValue('display');
  
    if (dotsStyleDisplay == "none") {
      dots.style.display = "none";
      btnText.innerHTML = "Λιγότερα";
      moreText.style.display = "block";
    } else {
      dots.style.display = "inline";
      btnText.innerHTML = "Περισσότερα";
      moreText.style.display = "none";
    }
  }

  function myFunction2() {
    let dots = document.querySelector(".dots2");
    let moreText = document.querySelector(".more2");
    let btnText = document.querySelector(".myBtn2");
    let dotsStyleDisplay = window.getComputedStyle(moreText).getPropertyValue('display');
  
    if (dotsStyleDisplay == "none") {
      dots.style.display = "none";
      btnText.innerHTML = "Λιγότερα";
      moreText.style.display = "block";
    } else {
      dots.style.display = "inline";
      btnText.innerHTML = "Περισσότερα";
      moreText.style.display = "none";
    }
  }


