function toggleMenu() {
    let slider = document.querySelector('.slider');
    let advs = document.querySelector('.advantages');
    let main = document.querySelector('.main');
    let footer = document.querySelector('.footer');
    let menuToggle = document.querySelector('.menu-toggle');
    let menuToggleDisplayStatus = window.getComputedStyle(menuToggle).getPropertyValue('display');

    if (menuToggleDisplayStatus == "none") {
        menuToggle.style.display = "block";
        //slider.style.display = "none";
        //advs.style.display = "none";
        //main.style.display = "none";
        //footer.style.display = "none";
    } else {
        menuToggle.style.display = "none";
        slider.style.display = "block";
        advs.style.display = "flex";
        main.style.display = "block";
        footer.style.display = "flex";
    }
}

function myFunctiona() {
    let dots = document.querySelector(".dotsa");
    let moreText = document.querySelector(".morea");
    let btnText = document.querySelector(".myBtna");
    let dotsStyleDisplay = window.getComputedStyle(moreText).getPropertyValue('display');
  
    if (dotsStyleDisplay == "none") {
      dots.style.display = "none";
      btnText.innerHTML = "Λιγότερα";
      moreText.style.display = "inline";
    } else {
      dots.style.display = "inline";
      btnText.innerHTML = "Περισσότερα";
      moreText.style.display = "none";
    }
  }

  function myFunctionb() {
    let dots = document.querySelector(".dotsb");
    let moreText = document.querySelector(".moreb");
    let btnText = document.querySelector(".myBtnb");
    let dotsStyleDisplay = window.getComputedStyle(moreText).getPropertyValue('display');
  
    if (dotsStyleDisplay == "none") {
      dots.style.display = "none";
      btnText.innerHTML = "Λιγότερα";
      moreText.style.display = "block";
    } else {
      dots.style.display = "inline";
      btnText.innerHTML = "Περισσότερα";
      moreText.style.display = "none";
    }
  }

  function myFunctionc() {
    let dots = document.querySelector(".dotsc");
    let moreText = document.querySelector(".morec");
    let btnText = document.querySelector(".myBtnc");
    let dotsStyleDisplay = window.getComputedStyle(moreText).getPropertyValue('display');
  
    if (dotsStyleDisplay == "none") {
      dots.style.display = "none";
      btnText.innerHTML = "Λιγότερα";
      moreText.style.display = "block";
    } else {
      dots.style.display = "inline";
      btnText.innerHTML = "Περισσότερα";
      moreText.style.display = "none";
    }
  }

  function myFunctiond() {
    let dots = document.querySelector(".dotsd");
    let moreText = document.querySelector(".mored");
    let btnText = document.querySelector(".myBtnd");
    let dotsStyleDisplay = window.getComputedStyle(moreText).getPropertyValue('display');
  
    if (dotsStyleDisplay == "none") {
      dots.style.display = "none";
      btnText.innerHTML = "Λιγότερα";
      moreText.style.display = "block";
    } else {
      dots.style.display = "inline";
      btnText.innerHTML = "Περισσότερα";
      moreText.style.display = "none";
    }
  }


